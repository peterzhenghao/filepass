#include <stdio.h>
#include "head.h"

int multiply(int a, int b)
{
    return a*b;
}